# 🧩 Dashboard de Pessoas — Sólides

Dashboard People Analytics integrado com a API do Sólides, desenvolvido em Python + Streamlit.

## 📦 Instalação

### 1. Pré-requisitos
- Python 3.10 ou superior
- pip atualizado

### 2. Clone ou baixe o projeto
```bash
# Se usar Git
git clone <seu-repositorio>
cd dashboard-solides

# Ou simplesmente coloque a pasta em qualquer local do seu computador
```

### 3. Crie o ambiente virtual (recomendado)
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 4. Instale as dependências
```bash
pip install -r requirements.txt
```

### 5. Configure o token da API
```bash
# Copie o arquivo de exemplo
cp .env.example .env

# Abra o .env e cole o seu token do Sólides
# SOLIDES_TOKEN=seu_token_aqui
```

> O token é obtido em: **Empregador → Integrações** na plataforma Sólides.

### 6. Execute o dashboard
```bash
streamlit run app.py
```

Acesse em: http://localhost:8501

---

## 🗂️ Estrutura do Projeto

```
dashboard-solides/
│
├── app.py                    # Entry point
├── requirements.txt
├── .env.example              # Modelo do arquivo de variáveis
├── .gitignore
│
├── api/
│   ├── solides_dp.py         # Cliente API Sólides DP (real)
│   └── mock_data.py          # Dados simulados para desenvolvimento
│
├── pages/
│   └── 01_visao_geral.py     # Módulo: KPIs e Headcount
│
└── components/
    └── charts.py             # Gráficos reutilizáveis (Plotly)
```

---

## 🔄 Trocar dados mock pela API real

No arquivo `pages/01_visao_geral.py`, localize a função `carregar_dados()`:

```python
# MOCK (desenvolvimento)
df = gerar_colaboradores(80)

# REAL (produção) — substitua por:
from api.solides_dp import get_colaboradores
dados = get_colaboradores()
df = pd.DataFrame(dados.get("content", []))
```

---

## 📍 Roadmap de Módulos

| Módulo              | Status        |
|---------------------|---------------|
| Visão Geral         | ✅ Pronto      |
| Cargos e Deptos     | 🔧 Em breve    |
| Perfil DISC         | 🔧 Em breve    |
| Mapa de Talentos    | 🔧 Em breve    |
