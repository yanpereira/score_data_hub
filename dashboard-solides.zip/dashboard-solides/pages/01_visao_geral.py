"""
Página 01 — Visão Geral
KPIs principais + Headcount por departamento + Admissões + Status
"""

import streamlit as st
import pandas as pd
from datetime import date
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from api.mock_data import gerar_colaboradores, gerar_admissoes_por_mes
from components.charts import (
    grafico_barras_departamento,
    grafico_pizza_status,
    grafico_admissoes,
    grafico_genero,
)

# ── Configurações da página ──────────────────────────────────────────────────
st.set_page_config(
    page_title="Visão Geral | Dashboard Pessoas",
    page_icon="👥",
    layout="wide",
)

# ── Estilo customizado ───────────────────────────────────────────────────────
st.markdown("""
<style>
    [data-testid="stAppViewContainer"] { background-color: #FAFAFA; }
    .kpi-card {
        background: white;
        border-radius: 12px;
        padding: 20px 24px;
        box-shadow: 0 1px 6px rgba(107,33,168,0.10);
        text-align: center;
        border-left: 4px solid #6B21A8;
    }
    .kpi-value { font-size: 2.2rem; font-weight: 700; color: #6B21A8; margin: 0; }
    .kpi-label { font-size: 0.85rem; color: #6B7280; margin: 0; }
    .kpi-delta { font-size: 0.8rem; color: #22C55E; margin-top: 4px; }
    .section-title {
        font-size: 1.1rem; font-weight: 600;
        color: #4C1D95; margin: 24px 0 8px 0;
        border-bottom: 2px solid #E9D5FF; padding-bottom: 6px;
    }
    div[data-testid="metric-container"] {
        background: white;
        border-radius: 12px;
        padding: 16px;
        box-shadow: 0 1px 6px rgba(107,33,168,0.10);
        border-left: 4px solid #6B21A8;
    }
</style>
""", unsafe_allow_html=True)

# ── Cabeçalho ────────────────────────────────────────────────────────────────
col_titulo, col_data = st.columns([3, 1])
with col_titulo:
    st.markdown("## 👥 Visão Geral de Pessoas")
    st.caption("Dashboard People Analytics • Dados via Sólides")
with col_data:
    st.markdown(f"<p style='text-align:right;color:#6B7280;font-size:0.85rem;margin-top:20px'>"
                f"📅 {date.today().strftime('%d/%m/%Y')}</p>", unsafe_allow_html=True)

st.divider()

# ── Carrega dados ────────────────────────────────────────────────────────────
@st.cache_data(ttl=300, show_spinner="Carregando dados do Sólides...")
def carregar_dados():
    df = gerar_colaboradores(80)
    admissoes = gerar_admissoes_por_mes(df)
    return df, admissoes

df, df_admissoes = carregar_dados()

# ── Filtros ──────────────────────────────────────────────────────────────────
with st.expander("🔍 Filtros", expanded=False):
    col_f1, col_f2 = st.columns(2)
    with col_f1:
        deptos = ["Todos"] + sorted(df["departamento"].unique().tolist())
        filtro_depto = st.selectbox("Departamento", deptos)
    with col_f2:
        status_opts = ["Todos"] + sorted(df["status"].unique().tolist())
        filtro_status = st.selectbox("Status", status_opts)

df_filtrado = df.copy()
if filtro_depto != "Todos":
    df_filtrado = df_filtrado[df_filtrado["departamento"] == filtro_depto]
if filtro_status != "Todos":
    df_filtrado = df_filtrado[df_filtrado["status"] == filtro_status]

# ── KPIs ─────────────────────────────────────────────────────────────────────
st.markdown('<p class="section-title">📊 Indicadores Principais</p>', unsafe_allow_html=True)

ativos        = len(df_filtrado[df_filtrado["status"] == "Ativo"])
total         = len(df_filtrado)
afastados     = len(df_filtrado[df_filtrado["status"] == "Afastado"])
ferias        = len(df_filtrado[df_filtrado["status"] == "Férias"])
novos_mes     = len(df_filtrado[
    pd.to_datetime(df_filtrado["data_admissao"]).dt.month == date.today().month
])
perc_ativos   = round((ativos / total * 100), 1) if total > 0 else 0

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("👥 Total de Colaboradores", total)
k2.metric("✅ Ativos", ativos, f"{perc_ativos}%")
k3.metric("🏖️ Em Férias", ferias)
k4.metric("🏥 Afastados", afastados)
k5.metric("🆕 Admitidos este mês", novos_mes)

# ── Gráficos principais ───────────────────────────────────────────────────────
st.markdown('<p class="section-title">📈 Distribuição & Movimentação</p>', unsafe_allow_html=True)

col1, col2 = st.columns([2, 1])
with col1:
    st.plotly_chart(grafico_barras_departamento(df_filtrado), use_container_width=True)
with col2:
    st.plotly_chart(grafico_pizza_status(df_filtrado), use_container_width=True)

col3, col4 = st.columns([3, 1])
with col3:
    st.plotly_chart(grafico_admissoes(df_admissoes), use_container_width=True)
with col4:
    st.plotly_chart(grafico_genero(df_filtrado), use_container_width=True)

# ── Tabela de colaboradores ───────────────────────────────────────────────────
st.markdown('<p class="section-title">📋 Lista de Colaboradores</p>', unsafe_allow_html=True)

df_exibir = df_filtrado[["nome", "departamento", "cargo", "status", "data_admissao"]].copy()
df_exibir.columns = ["Nome", "Departamento", "Cargo", "Status", "Admissão"]
df_exibir["Admissão"] = pd.to_datetime(df_exibir["Admissão"]).dt.strftime("%d/%m/%Y")

st.dataframe(
    df_exibir,
    use_container_width=True,
    hide_index=True,
    height=300,
)

st.caption(f"Exibindo {len(df_exibir)} colaboradores")
