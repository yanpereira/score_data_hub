"""
Componentes de gráficos reutilizáveis com Plotly.
Paleta de cores alinhada com a identidade visual da Sólides.
"""

import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

# Paleta Sólides
CORES = {
    "primaria":   "#6B21A8",   # roxo sólides
    "secundaria": "#A855F7",
    "acento":     "#E9D5FF",
    "sucesso":    "#22C55E",
    "alerta":     "#F59E0B",
    "erro":       "#EF4444",
    "neutro":     "#6B7280",
}

SEQUENCIA_CORES = [
    "#6B21A8", "#A855F7", "#7C3AED", "#9333EA",
    "#C084FC", "#DDD6FE", "#4C1D95", "#8B5CF6",
]


def card_kpi(label: str, valor, delta=None, prefixo="", sufixo="") -> go.Figure:
    """Indicador tipo KPI card."""
    fig = go.Figure(go.Indicator(
        mode="number+delta" if delta is not None else "number",
        value=valor,
        delta={"reference": valor - delta, "valueformat": ".0f"} if delta else None,
        title={"text": label, "font": {"size": 14, "color": "#374151"}},
        number={"prefix": prefixo, "suffix": sufixo,
                "font": {"size": 36, "color": CORES["primaria"]}},
    ))
    fig.update_layout(
        height=140,
        margin=dict(l=20, r=20, t=40, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
    )
    return fig


def grafico_barras_departamento(df: pd.DataFrame) -> go.Figure:
    """Headcount por departamento — barras horizontais."""
    contagem = (
        df[df["status"] == "Ativo"]
        .groupby("departamento")
        .size()
        .reset_index(name="total")
        .sort_values("total", ascending=True)
    )
    fig = px.bar(
        contagem,
        x="total",
        y="departamento",
        orientation="h",
        text="total",
        color="total",
        color_continuous_scale=["#E9D5FF", "#6B21A8"],
        labels={"total": "Colaboradores", "departamento": ""},
        title="👥 Headcount por Departamento",
    )
    fig.update_traces(textposition="outside")
    fig.update_layout(
        coloraxis_showscale=False,
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, sans-serif"),
        title_font_size=15,
        height=380,
        margin=dict(l=10, r=30, t=50, b=10),
    )
    return fig


def grafico_pizza_status(df: pd.DataFrame) -> go.Figure:
    """Distribuição de status dos colaboradores."""
    contagem = df["status"].value_counts().reset_index()
    contagem.columns = ["status", "total"]

    cores_status = {
        "Ativo": CORES["sucesso"],
        "Afastado": CORES["alerta"],
        "Férias": CORES["secundaria"],
        "Desligado": CORES["erro"],
    }

    fig = px.pie(
        contagem,
        names="status",
        values="total",
        color="status",
        color_discrete_map=cores_status,
        hole=0.55,
        title="📊 Status dos Colaboradores",
    )
    fig.update_traces(textinfo="percent+label", pull=[0.03] * len(contagem))
    fig.update_layout(
        showlegend=False,
        paper_bgcolor="rgba(0,0,0,0)",
        title_font_size=15,
        height=340,
        margin=dict(l=10, r=10, t=50, b=10),
    )
    return fig


def grafico_admissoes(df_admissoes: pd.DataFrame) -> go.Figure:
    """Linha de admissões nos últimos 12 meses."""
    fig = px.area(
        df_admissoes,
        x="mes_admissao",
        y="admissoes",
        markers=True,
        title="📈 Admissões — Últimos 12 Meses",
        labels={"mes_admissao": "Mês", "admissoes": "Admissões"},
        color_discrete_sequence=[CORES["primaria"]],
    )
    fig.update_traces(fill="tozeroy", fillcolor="rgba(107,33,168,0.12)")
    fig.update_layout(
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(showgrid=False, tickangle=-30),
        yaxis=dict(showgrid=True, gridcolor="#F3E8FF"),
        title_font_size=15,
        height=300,
        margin=dict(l=10, r=10, t=50, b=40),
    )
    return fig


def grafico_genero(df: pd.DataFrame) -> go.Figure:
    """Distribuição por gênero."""
    contagem = df[df["status"] == "Ativo"]["genero"].value_counts().reset_index()
    contagem.columns = ["genero", "total"]
    fig = px.bar(
        contagem,
        x="genero",
        y="total",
        text="total",
        color="genero",
        color_discrete_sequence=SEQUENCIA_CORES,
        title="⚧ Diversidade de Gênero",
        labels={"genero": "", "total": ""},
    )
    fig.update_traces(textposition="outside")
    fig.update_layout(
        showlegend=False,
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        title_font_size=15,
        height=300,
        margin=dict(l=10, r=10, t=50, b=10),
    )
    return fig
