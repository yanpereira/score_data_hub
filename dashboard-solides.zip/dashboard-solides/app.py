"""
Dashboard de Pessoas — Sólides
Entry point principal da aplicação Streamlit.
"""

import streamlit as st

st.set_page_config(
    page_title="Dashboard Pessoas | Sólides",
    page_icon="🧩",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    [data-testid="stSidebarNav"] { padding-top: 1rem; }
    .logo-text {
        font-size: 1.6rem;
        font-weight: 800;
        color: #6B21A8;
    }
    .sub-text { color: #6B7280; font-size: 0.85rem; }
</style>
""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<p class="logo-text">🧩 People Analytics</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-text">Powered by Sólides</p>', unsafe_allow_html=True)
    st.divider()
    st.markdown("**Navegação**")
    st.page_link("pages/01_visao_geral.py",    label="👥 Visão Geral",             icon="📊")
    st.divider()
    st.caption("Módulos em breve:")
    st.markdown("🔒 Cargos e Departamentos")
    st.markdown("🔒 Perfil Comportamental")
    st.markdown("🔒 Mapa de Talentos")
    st.divider()
    st.caption("v1.0.0 • Dados via API Sólides")

# ── Home ───────────────────────────────────────────────────────────────────────
st.markdown("## 👋 Bem-vindo ao Dashboard de Pessoas")
st.markdown("""
Este painel centraliza os dados de colaboradores da sua empresa,
integrando diretamente com a **API do Sólides**.

Use o menu lateral para navegar entre os módulos.
""")

col1, col2, col3, col4 = st.columns(4)
col1.info("**👥 Visão Geral**\nKPIs e Headcount")
col2.warning("**🏢 Departamentos**\n*Em desenvolvimento*")
col3.warning("**🧠 Perfil DISC**\n*Em desenvolvimento*")
col4.warning("**🗺️ Mapa de Talentos**\n*Em desenvolvimento*")
