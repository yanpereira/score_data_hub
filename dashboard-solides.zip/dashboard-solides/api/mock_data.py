"""
Dados simulados para desenvolvimento local.
Substitua pelas chamadas reais da API quando tiver o token configurado.
"""

import pandas as pd
import random
from datetime import date, timedelta

random.seed(42)

DEPARTAMENTOS = [
    "Financeiro", "Tecnologia", "RH", "Comercial",
    "Operações", "Marketing", "Jurídico", "Logística"
]

CARGOS = {
    "Financeiro":  ["Analista Financeiro", "Contador", "Auxiliar Financeiro"],
    "Tecnologia":  ["Desenvolvedor", "DevOps", "QA", "Product Manager"],
    "RH":          ["Analista de RH", "Recrutador", "HRBP"],
    "Comercial":   ["Vendedor", "Gerente Comercial", "SDR"],
    "Operações":   ["Analista de Operações", "Supervisor", "Auxiliar"],
    "Marketing":   ["Designer", "Analista de Marketing", "Social Media"],
    "Jurídico":    ["Advogado", "Paralegal", "Analista Jurídico"],
    "Logística":   ["Motorista", "Coordenador de Logística", "Almoxarife"],
}

PERFIS_DISC = ["Executor", "Comunicador", "Planejador", "Analista"]
STATUS = ["Ativo", "Ativo", "Ativo", "Ativo", "Afastado", "Férias"]


def gerar_colaboradores(n: int = 80) -> pd.DataFrame:
    """Gera DataFrame com colaboradores simulados."""
    nomes = [
        "Ana Lima", "Bruno Souza", "Carla Mendes", "Diego Rocha",
        "Eliane Costa", "Felipe Dias", "Gisele Nunes", "Henrique Alves",
        "Isabela Ferreira", "João Martins", "Karen Oliveira", "Lucas Pereira",
        "Marina Santos", "Nicolas Ribeiro", "Olga Monteiro", "Paulo Freitas",
        "Quésia Barros", "Rafael Torres", "Sabrina Melo", "Thiago Azevedo",
        "Úrsula Campos", "Victor Gomes", "Wanda Silveira", "Xênia Moura",
        "Yuri Cardoso", "Zara Pinto", "Adriano Lopes", "Beatriz Cruz",
        "Caio Fonseca", "Daniela Borges", "Eduardo Reis", "Fernanda Guimarães",
        "Gustavo Moreira", "Helena Araújo", "Igor Nascimento", "Juliana Cavalcante",
        "Kelvin Correia", "Larissa Vieira", "Márcio Teixeira", "Natália Duarte",
        "Oscar Rodrigues", "Patricia Cunha", "Quirino Batista", "Renata Carvalho",
        "Sandro Lima", "Tatiane Pinheiro", "Ulisses Fontes", "Viviane Marques",
        "Wagner Paiva", "Xuxa Medeiros",
    ]
    # repete se necessário
    while len(nomes) < n:
        nomes += [f"Colaborador {i}" for i in range(len(nomes), n)]

    records = []
    for i in range(n):
        depto = random.choice(DEPARTAMENTOS)
        cargo = random.choice(CARGOS[depto])
        admissao = date.today() - timedelta(days=random.randint(30, 2000))
        records.append({
            "id": i + 1,
            "nome": nomes[i % len(nomes)],
            "departamento": depto,
            "cargo": cargo,
            "perfil_disc": random.choice(PERFIS_DISC),
            "status": random.choice(STATUS),
            "data_admissao": admissao,
            "salario": round(random.uniform(2000, 15000), 2),
            "genero": random.choice(["Masculino", "Feminino", "Não informado"]),
        })

    return pd.DataFrame(records)


def gerar_admissoes_por_mes(df: pd.DataFrame) -> pd.DataFrame:
    """Agrupa admissões por mês/ano."""
    df = df.copy()
    df["mes_admissao"] = pd.to_datetime(df["data_admissao"]).dt.to_period("M")
    contagem = (
        df.groupby("mes_admissao")
        .size()
        .reset_index(name="admissoes")
        .sort_values("mes_admissao")
        .tail(12)
    )
    contagem["mes_admissao"] = contagem["mes_admissao"].astype(str)
    return contagem
