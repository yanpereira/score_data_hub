"""
Cliente para a API do Sólides DP
Documentação: https://docs.tangerino.com.br
Autenticação: Basic Authorization com token JWT
"""

import os
import requests
from dotenv import load_dotenv

load_dotenv()

BASE_URL = "https://api.tangerino.com.br"


def _get_headers():
    token = os.getenv("SOLIDES_TOKEN", "")
    return {
        "Authorization": f"Basic {token}",
        "Content-Type": "application/json",
    }


def get_colaboradores(page: int = 0, size: int = 100) -> dict:
    """
    GET /employee/find-all
    Retorna lista paginada de colaboradores ativos.
    """
    try:
        url = f"{BASE_URL}/employee/find-all"
        params = {"page": page, "size": size}
        response = requests.get(url, headers=_get_headers(), params=params, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": str(e), "content": [], "totalElements": 0}


def get_cargos() -> dict:
    """
    GET /job-role/find-all
    Retorna todos os cargos cadastrados.
    """
    try:
        url = f"{BASE_URL}/job-role/find-all"
        response = requests.get(url, headers=_get_headers(), timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": str(e), "content": []}


def get_departamentos() -> dict:
    """
    GET /workplace/find-all
    Retorna todos os locais/departamentos cadastrados.
    """
    try:
        url = f"{BASE_URL}/workplace/find-all"
        response = requests.get(url, headers=_get_headers(), timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": str(e), "content": []}
